<?php
    require_once("classes/question.class.php");
    require_once("classes/reponse.class.php");
    require_once("classes/monPDO.class.php");
?>

<?php 
class Qcm{
    public $id_qcm;
    public $questions=array();
    private $appreciation=array();
    private $nom;




    public function __construct(){
        $ctp = func_num_args();
        $args = func_get_args();
        
        switch($ctp)
        {
            case 1:
                $pdo = monPDO::getPDO();
                $stmt = $pdo->prepare("SELECT * from qcm where id_qcm=".$args[0]);
                $stmt->execute();
                $qcm = $stmt->fetchAll();
                $qcm=$qcm[0];
                $this->nom=$qcm['nom'];
                $this->appreciation=unserialize($qcm['appreciation']);
                $stmt = $pdo->prepare("SELECT id_question from myquestion where id_qcm =".$args[0]);
                $stmt->execute();
                $questions = $stmt->fetchAll();
                foreach($questions as $question){
                    $this->questions[]=new question($question['id_question']);
                }
                break;
             default:
                break;
        }
    }    
    

   
   
    public function addQuestion($question){
        $this->questions[]=$question;
    
    }
     
    public function getQuestions(){
        return $this->questions;
    }

    public function getQuestion($number){
        return $this->reponses[$number];
    }

    public function getAppreciation(){
        return $this->appreciation;
    }

    public function setAppreciation($appreciation){
        $this->appreciation=$appreciation;
    }

    public function getNom(){
        return $this->nom;
    }

    public function setNom($nom){
        $this->nom=$nom;
    }

    public function persiste(){
            $pdo = monPDO::getPDO();
            $stmt = $pdo->prepare("INSERT INTO qcm (nom,appreciation)
            VALUES ( :nom, :appreciation)");
            $appreciation=serialize($this->appreciation);
            $stmt->bindParam(':nom', $this->nom);
            $stmt->bindParam(':appreciation', $appreciation);
            $stmt-> execute();

            $id_qcm=$pdo->lastInsertId();
            foreach($this->questions as $question ){
                $question->persiste($id_qcm);
            
            }
    }
    
}



?>