<?php
    require_once("classes/question.class.php");
    require_once("classes/reponse.class.php");
    require_once("classes/monPDO.class.php");
?>

<?php 
class Question{
    public $id_question;
    public $contenu;
    public $reponses=array();
    private $explication;




    public function __construct(){
        $ctp = func_num_args();
        $args = func_get_args();
        
        switch($ctp)
        {
            case 1:
                $pdo = monPDO::getPDO();
                $stmt = $pdo->prepare("Select * from myquestion where id_question=".$args[0]);
                $stmt->execute();
                $question = $stmt->fetchAll();
                $qu = $question[0];
                $this->id_question=$qu['id_question'];
                $this->contenu = $qu['contenu'];
                $this->explication = $qu['explication'];
        
                $stmt = $pdo->prepare("Select * from reponse where id_question=".$args[0]);
                $stmt->execute();
                $reponses = $stmt->fetchAll();
                foreach($reponses as $repons){

                    $this->reponses[] = new Reponse($repons['contenu'],$repons['isCorrect'] );
                    
                    
                    
                }     
                break;
             default:
                break;
        }
    }    
    

    public function getidQuestion(){
        return $this->id_question;
    }
    public function getContenu(){
        return $this->contenu;
    }
    

    public function setContenu($contenu){
        $this->contenu = $contenu;
    }

    public function getExplication(){
        return $this->explication;
    }
    

    public function setExplication($explication){
        $this->explication = $explication;
    }
   
    public function addReponse($reponse){
        $this->reponses[]=$reponse;
    
    }
     
    public function getReponses(){
        return $this->reponses;
    }
    public function getReponse($number){
        return $this->reponses[$number];
    }
    public function persiste($id_qcm){
            $pdo = monPDO::getPDO();
            $stmt = $pdo->prepare("INSERT INTO myquestion (contenu,explication,id_qcm)
            VALUES ( :contenu,:explication,:id_qcm)");
            $stmt->bindParam(':contenu', $this->contenu);
            $stmt->bindParam(':explication', $this->explication);
            $stmt->bindParam(':id_qcm', $id_qcm);
            $stmt-> execute();
            $id_question=$pdo->lastInsertId();
            foreach($this->reponses as $reponse ){
            $reponse->persiste($id_question);
            
            }
    }
    
}



?>