<?php
class reponse{
    private $id_reponse;
    public $contenu;
    private $Correct;


    public function __construct($contenu,$Correct){
       
        $this->contenu=$contenu;
        $this->Correct=$Correct;
    }

    public function getidReponse(){
        return $this->id_reponse;
    }
    public function getContenu(){
        return $this->contenu;
    }
    public function setContenu($contenu){
        $this->contenu=$contenu;
    }

    public function getCorrect(){
        return $this->Correct;
    }
    public function setCorrect($correct){
        $this->correct=$correct;
    }


    public function persiste($id_question){
    $pdo = monPDO::getPDO();
    $stmt = $pdo->prepare("INSERT INTO reponse (id_question,contenu,isCorrect)
    VALUES ( :id_question, :contenu, :isCorrect)");
    $stmt->bindParam(':contenu', $this->contenu);
    $stmt->bindParam(':isCorrect', $this->Correct);
    $stmt->bindParam(':id_question', $id_question);
    $stmt-> execute();
}
    // public function __toString(){
    //     $affichage .= "Nombre : " . $this->nombre . "<br />";
    //     $affichage .= "contenu : " . $this->contenu . "<br />";

    //     return $affichage;
    // }
}
?>