<?php
    require_once("classes/question.class.php");
    require_once("classes/reponse.class.php");
    require_once("classes/monPDO.class.php");
    include("common/header.php");
    include("common/menu.php");  
    $pdo = monPDO::getPDO();
    $stmt = $pdo->prepare("Select id_question from myquestion");
    $stmt->execute();
    $questions = $stmt->fetchAll();
    if(isset($_POST['valider'])){
      $nbQuestion=0;
      $nbBonneReponse=0;
      foreach($questions as $question){
        $nbQuestion++;
        if(isset($_POST[$question['id_question']])){
          $q = new Question( $question['id_question']);
          $rep = $q->getReponse($_POST[$question['id_question']][0]);
          if($rep->getCorrect() == 1){
            $nbBonneReponse++;
          }
               
      }
        
    }
}
?>
<form method ="POST">


<?php
    if(!isset($_POST['valider'])){
       echo "<h1> Les questions: </h1>";    
       foreach($questions as $question){
        $q = new Question( $question['id_question']);
        echo "<div class='p-3 mb-2 bg-primary text-white'>".$q->getContenu()."</div>";
        $i=0;
        foreach($q->getReponses() as $reponse){
            echo "<input value='$i' name='".$q->getidQuestion()."[]' type='radio'>";
            
            echo "<p class='font-weight-bold'>"."&nbsp"."&nbsp"."&nbsp".$reponse->getContenu()."</p>";

           
            ;
            


            
            $i++;
        }
    
      } 
  }
    else{
       echo "<h1> Résultats: </h1>";
       if ( $nbBonneReponse == $nbQuestion){
        echo "<div class='alert alert-warning' role='alert'>
        t'as eu la totalité des points !
            </div>";
       }
       else if ($nbBonneReponse == ($nbQuestion/2)){
        echo "<div class='alert alert-warning' role='alert'>
        t'as eu la moyenne !
            </div>";
       }
       else if ($nbBonneReponse >= ($nbQuestion/2)){
        echo "<div class='alert alert-warning' role='alert'>
        t'as eu plus que la moyenne !
            </div>";
       }

      else {
        echo "<div class='alert alert-warning' role='alert'>
        t'as pas eu moyenne !
            </div>";

      }
      
         
       
       echo " <div class='badge badge-primary text-wrap' style='width: 6rem;'>"
           .$nbBonneReponse."/".$nbQuestion.
              "</div>";
       echo"</br>";
       echo "<h4> Les explications des questions: </h4>";    


       foreach($questions as $question){
        $q = new Question( $question['id_question']);
        
        echo "<div class='p-3 mb-2 bg-primary text-white'>".$q->getContenu()."</div>";
        echo "<p class='font-weight-bold'>"."&nbsp"."&nbsp"."&nbsp".$q->getExplication()."</p>";


        echo"</br>";
        

       }    
       }
?> 
  <input id = 'valider' value='valider' name='valider' type='submit'><br/>

</form>







<?php 
    include("common/footer.php");
?>