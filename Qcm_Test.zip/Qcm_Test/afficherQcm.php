<?php
    require_once("classes/question.class.php");
    require_once("classes/qcm.class.php");
    require_once("classes/reponse.class.php");
    require_once("classes/monPDO.class.php");
    include("common/header.php");
    include("common/menu.php");  
    session_start();
    
?>
<form method ="POST">


<?php

if((!isset($_SESSION['id_qcm']) && !isset($_POST['id_qcm']))){
  $pdo = monPDO::getPDO();
  $stmt = $pdo->prepare("Select * from qcm");
  $stmt->execute();
  $qcm = $stmt->fetchAll();
  echo "<select name='id_qcm' >";
    foreach($qcm as $q){
      echo "<option value='".$q['id_qcm']."'>".$q['nom']."</option>";
    }
  echo "</select>";
}else{
  if(isset($_POST['id_qcm'])){
    $_SESSION['id_qcm']=$_POST['id_qcm'];
  }
  $qcm = new qcm($_SESSION['id_qcm']);
  $questions=$qcm->getQuestions();
  if(isset($_POST['valider'])){
      $nbQuestion=0;
      $nbBonneReponse=0;
      foreach($questions as $q){
          $nbQuestion++;
          if(isset($_POST[$q->getidQuestion()])){
              $rep = $q->getReponse($_POST[$q->getIdQuestion()][0]);
              if($rep->getCorrect() == 1){
                  $nbBonneReponse++;
              }
            
          }
      
      } 
  }
  if(!isset($_POST['valider'])){
    echo "<h1> Les questions: </h1>";    
    foreach($questions as $q){
     
     echo "<div class='p-3 mb-2 bg-primary text-white'>".$q->getContenu()."</div>";
     $i=0;
     foreach($q->getReponses() as $reponse){
         echo "<input value='$i' name='".$q->getidQuestion()."[]' type='radio'>";
         echo "<p class='font-weight-bold'>"."&nbsp"."&nbsp"."&nbsp".$reponse->getContenu()."</p>";
         $i++;
     }
 
   } 
}
 else{
    unset($_SESSION['id_question']);
    echo "<h1> Résultats: </h1>";
    print_r($nbBonneReponse/$nbQuestion );
    if ( ($nbBonneReponse/$nbQuestion) >= 0.5){
      echo "<div class='alert alert-warning' role='alert'>";
      echo $qcm->getAppreciation()['10_20'];
      echo "</div>";
    }
    else {
      echo "<div class='alert alert-warning' role='alert'>";
      echo $qcm->getAppreciation()['0-10'];
      echo "</div>";
    }
   
   
      
    
    echo " <div class='badge badge-primary text-wrap' style='width: 6rem;'>"
        .$nbBonneReponse."/".$nbQuestion.
           "</div>";
    echo"</br>";
    echo "<h4> Les explications des questions: </h4>";    


    foreach($questions as $q){
     
     
     echo "<div class='p-3 mb-2 bg-primary text-white'>".$q->getContenu()."</div>";
     echo "<p class='font-weight-bold'>"."&nbsp"."&nbsp"."&nbsp".$q->getExplication()."</p>";


     echo"</br>";

    }    
  }
}
    
?> 
  <input id = 'valider' value='valider' name='valider' type='submit'><br/>

</form>







<?php 
    include("common/footer.php");
?>