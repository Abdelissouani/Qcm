<nav>
    <ul>
        <li><a href="index.php">Accueil</a></li>
        <li><a href="gestionquestion.php">Gestion des questions</a></li>
        <li><a href="afficherQcm.php">QCM</a></li>
        
    </ul>
</nav>