<?php
require_once("classes/question.class.php");
require_once("classes/reponse.class.php");
require_once("classes/qcm.class.php");
include("common/header.php");
include("common/menu.php");
?>
<h1> Créer un nouveau qcm : </h1>
   <form method ="POST" >
       <fieldset header="Creation d'un qcm:">

    <?php  if (isset($_POST['terminerQcm'])) { ?>
            <input type='submit' value='ajouter un nouveau qcm' />

    <?php }elseif (isset($_POST['bonneReponse']) || (isset($_POST['mauvaiseReponse']) && !isset($_POST['terminerQuestion']))) { ?>
        <div class='input-group input-group-sm mb-3'>
        <div class='input-group-prepend'>
        <span class='input-group-text' id='inputGroup-sizing-sm'>Mauvaise Réponse</span>
            </div>
        <input name='mauvaiseReponse' type='text' class='form-control' aria-label='Sizing example input' aria-describedby='inputGroup-sizing-sm'>
        </div>
        <input type='submit' value='ajouter mauvaise réponse' />
        <input name='terminerQuestion' type='submit' value='question Suivante' />
        <input name='terminerQcm' type='submit' value='fin qcm' />

    <?php  }elseif (isset($_POST['ajouteQuestion'])) { ?>
           
                <div class='input-group input-group-sm mb-3'>
                <div class='input-group-prepend'>
                <span class='input-group-text' id='inputGroup-sizing-sm'>Bonne Réponse</span>
                 </div>
                <input name='bonneReponse' type='text' class='form-control' aria-label='Sizing example input' aria-describedby='inputGroup-sizing-sm'>
                </div>
                
                <input type='submit' value='ajouter' />

    <?php }elseif (isset($_POST['nomQcm'])|| isset($_POST['terminerQuestion'])) { ?>
                <div class='input-group input-group-sm mb-3'>
                    <div class='input-group-prepend'>
                    <span class='input-group-text' id='inputGroup-sizing-sm'>Question</span>
                    </div>
                    <input name='ajouteQuestion' type='text' class='form-control' aria-label='Sizing example input' aria-describedby='inputGroup-sizing-sm'>
                </div>
                <div class='input-group input-group-sm mb-3'>
                    <div class='input-group-prepend'>
                    <span class='input-group-text' id='inputGroup-sizing-sm'>Explication</span>
                    </div>
                    <input name='explication' type='text' class='form-control' aria-label='Sizing example input' aria-describedby='inputGroup-sizing-sm'>
                </div> </br>
                </br>
                <input type='submit' value='suivant' />
        
            <?php }else { ?>
                
                <div class='input-group input-group-sm mb-3'>
                    <div class='input-group-prepend'>
                    <span class='input-group-text' id='inputGroup-sizing-sm'>Nom qcm</span>
                    </div>
                    <input name='nomQcm' type='text' class='form-control' aria-label='Sizing example input' aria-describedby='inputGroup-sizing-sm'>
                </div>
                <div class='input-group input-group-sm mb-3'>
                    <div class='input-group-prepend'>
                    <span class='input-group-text' id='inputGroup-sizing-sm'>appreciation note >= 10</span>
                    </div>
                    <input name='appBonneNote' type='text' class='form-control' aria-label='Sizing example input' aria-describedby='inputGroup-sizing-sm'>
                </div>
                <div class='input-group input-group-sm mb-3'>
                    <div class='input-group-prepend'>
                    <span class='input-group-text' id='inputGroup-sizing-sm'>appreciation note < 10</span>
                    </div>
                    <input name='appMauvaiseNote' type='text' class='form-control' aria-label='Sizing example input' aria-describedby='inputGroup-sizing-sm'>
                </div>
                 </br>
                <input type='submit' value='suivant' />
            <?php } ?>
        </fieldset>
    </form>







<?php 
    if(isset($_POST['nomQcm'])){
        $qcm=new Qcm();
        $qcm->setNom($_POST['nomQcm']);
        $qcm->setAppreciation(array('0-10' => $_POST['appMauvaiseNote'], '10-20' => $_POST['appBonneNote']));
        file_put_contents('createQcm', serialize($qcm));
    }
    if(isset($_POST['ajouteQuestion'])){
        $question=new question();
        $question->setContenu($_POST['ajouteQuestion']);
        if(isset($_POST['explication'])){
            $question->setExplication($_POST['explication']);
        }
        file_put_contents('createQuestion', serialize($question));
    }
    if(isset($_POST['bonneReponse'])){
        
        $s = file_get_contents('createQuestion');
        $question=unserialize($s);
        $question->addReponse(new reponse($_POST['bonneReponse'],1));
        $question= serialize($question);
        file_put_contents('createQuestion', $question);
        

    }if(isset($_POST['mauvaiseReponse']) and !isset($_POST['terminerQuestion'])){
        
        $s = file_get_contents('createQuestion');
        $question=unserialize($s);
        $question->addReponse(new reponse($_POST['mauvaiseReponse'],0));
        $question= serialize($question);
        file_put_contents('createQuestion', $question);
    }if(isset($_POST['terminerQuestion'])){
        
        $s = file_get_contents('createQcm');
        $qcm=unserialize($s);
        $s = file_get_contents('createQuestion');
        $question=unserialize($s);
        if(isset($_POST['mauvaiseReponse'])){
            $question->addReponse(new reponse($_POST['mauvaiseReponse'],0));
        }
        $qcm->addQuestion($question);
        file_put_contents('createQcm', serialize($qcm));
        
    }if(isset($_POST['terminerQcm'])){
        
        $s = file_get_contents('createQcm');
        $qcm=unserialize($s);
        $s = file_get_contents('createQuestion');
        $question=unserialize($s);
        if(isset($_POST['mauvaiseReponse'])){
            $question->addReponse(new reponse($_POST['mauvaiseReponse'],0));
        }
        $qcm->addQuestion($question);
        $qcm->persiste();
        echo "<div class='p-3 mb-2 bg-primary text-white'>Qcm enregistré</div>";
    }

        

?>




<?php 
    include("common/footer.php");
?>