<?php
require_once("classes/question.class.php");
require_once("classes/reponse.class.php");
include("common/header.php");
include("common/menu.php");
?>
<h1> Créer une nouvelle question : </h1>
   <form method ="POST" >
       <fieldset header="Question :">
            <?php 
            if (isset($_POST['contenu'])) { 
                echo "<div class='input-group input-group-sm mb-3'>
                <div class='input-group-prepend'>
                <span class='input-group-text' id='inputGroup-sizing-sm'>Bonne Réponse</span>
                 </div>
                <input name='bonneReponse' type='text' class='form-control' aria-label='Sizing example input' aria-describedby='inputGroup-sizing-sm'>
                </div>
                
                <input type='submit' value='suivant' />";
            }
            
                elseif (isset($_POST['bonneReponse']) || isset($_POST['mauvaiseReponse'])) {
                echo"<div class='input-group input-group-sm mb-3'>
                <div class='input-group-prepend'>
                <span class='input-group-text' id='inputGroup-sizing-sm'>Mauvaise Réponse</span>
                 </div>
                <input name='mauvaiseReponse' type='text' class='form-control' aria-label='Sizing example input' aria-describedby='inputGroup-sizing-sm'>
                </div>
                <input type='submit' value='suivant' />
                <input name='terminer' type='submit' value='terminer' />";}
                 else {
                echo"
                <div class='input-group input-group-sm mb-3'>
                <div class='input-group-prepend'>
                <span class='input-group-text' id='inputGroup-sizing-sm'>Question</span>
                 </div>
                <input name='contenu' type='text' class='form-control' aria-label='Sizing example input' aria-describedby='inputGroup-sizing-sm'>
                </div>
                <div class='input-group input-group-sm mb-3'>
                <div class='input-group-prepend'>
                <span class='input-group-text' id='inputGroup-sizing-sm'>Explication</span>
                 </div>
                <input name='explication' type='text' class='form-control' aria-label='Sizing example input' aria-describedby='inputGroup-sizing-sm'>
                </div> </br>
                <input type='submit' value='suivant' />";}

            ?>

        </fieldset>
    </form>







<?php 
    
    if(isset($_POST['contenu'])){
        
        $question=new question();
        $question->setContenu($_POST['contenu']);
        if(isset($_POST['explication'])){
            $question->setExplication($_POST['explication']);
        }
        $question= serialize($question);
        file_put_contents('createQuestion', $question);
    }
    elseif(isset($_POST['bonneReponse'])){
        
        $s = file_get_contents('createQuestion');
        $question=unserialize($s);
        $question->addReponse(new reponse($_POST['bonneReponse'],1));
        $question= serialize($question);
        file_put_contents('createQuestion', $question);
        

    }elseif(isset($_POST['mauvaiseReponse']) and !isset($_POST['terminer'])){
        
        $s = file_get_contents('createQuestion');
        $question=unserialize($s);
        $question->addReponse(new reponse($_POST['mauvaiseReponse'],0));
        $question= serialize($question);
        file_put_contents('createQuestion', $question);
    }elseif(isset($_POST['terminer'])){
        
        $s = file_get_contents('createQuestion');
        $question=unserialize($s);
        if(isset($_POST['mauvaiseReponse'])){
            $question->addReponse(new reponse($_POST['mauvaiseReponse'],0));
        }
        $question->persiste();
        echo "<div class='p-3 mb-2 bg-primary text-white'>Question enregistré</div>";
    }

        

?>




<?php 
    include("common/footer.php");
?>