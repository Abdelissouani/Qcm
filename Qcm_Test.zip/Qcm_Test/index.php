
<?php 
    include("common/header.php");
    include("common/menu.php");
?>
<h1>Bienvenue</h1>
<?php 
    include("common/footer.php");
?>